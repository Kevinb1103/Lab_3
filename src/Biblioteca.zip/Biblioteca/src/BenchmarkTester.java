import java.io.*;
import java.util.*;

public class BenchmarkTester {

    static String[] files = {"games_100.csv", "games_10000.csv", "games_1000000.csv"};
    static String[] algorithms = {"bubbleSort", "insertionSort", "selectionSort", "mergeSort", "quickSort", "collectionsSort"};
    static String attribute = "quality";  //aca se cambia el atributo para hacer las pruebas en cada caso

    public static void main(String[] args) throws IOException {
        System.out.println("\n=== Resultados para atributo: " + attribute + " ===");
        System.out.printf("%-18s %-15s %-20s\n", "Algoritmo", "Tamaño Dataset", "Tiempo Promedio (ms)");
        for (String file : files) {
            int n = getSizeFromFileName(file);
            ArrayList<Game> originalList = loadGamesFromFile(file);
            for (String algo : algorithms) {
                long totalTime = 0;
                for (int i = 0; i < 3; i++) {
                    ArrayList<Game> copiedList = deepCopy(originalList);
                    Dataset ds = new Dataset(copiedList);
                    long start = System.currentTimeMillis();
                    ds.sortByAlgorithm(algo, attribute);
                    long end = System.currentTimeMillis();
                    long elapsed = end - start;
                    if (elapsed > 300000) {  // 5 minutos = 300,000 ms
                        totalTime = -1; // más de 300 segundos
                        break;
                    }
                    totalTime += elapsed;
                }
                if (totalTime == -1) {
                    System.out.printf("%-18s %-15d %-20s\n", algo, n, "> 300000 ms");
                } else {
                    System.out.printf("%-18s %-15d %-20d\n", algo, n, totalTime / 3);
                }
            }
        }
    }

    static int getSizeFromFileName(String filename) {
        if (filename.contains("1000000")) return 1000000;
        if (filename.contains("10000")) return 10000;
        return 100;
    }

    static ArrayList<Game> loadGamesFromFile(String filename) throws IOException {
        ArrayList<Game> list = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            String name = parts[0];
            String category = parts[1];
            int price = Integer.parseInt(parts[2]);
            int quality = Integer.parseInt(parts[3]);
            list.add(new Game(name, category, price, quality));
        }
        br.close();
        return list;
    }

    static ArrayList<Game> deepCopy(ArrayList<Game> original) {
        ArrayList<Game> copy = new ArrayList<>();
        for (Game g : original) {
            copy.add(new Game(g.getName(), g.getCategory(), g.getPrice(), g.getQuality()));
        }
        return copy;
    }
}