import java.io.*;
import java.util.ArrayList;

public class SearchBenchmarkLinear {

    static String filename = "games_1000000.csv";  // Cambia al path correcto

    public static void main(String[] args) throws IOException {
        // Cargar dataset
        ArrayList<Game> games = loadGamesFromFile(filename);
        Dataset ds = new Dataset(games);
        ds.sortedByAttribute = "";  // Forzar que se detecte sin orden para búsqueda lineal

        // Parámetros de búsqueda
        int priceToSearch = 25000;        // valor arbitrario que esté en el rango
        int lowerPrice = 20000;
        int higherPrice = 30000;
        String categoryToSearch = "Action";  // poné alguna categoría que exista en tu dataset

        // Número de repeticiones para medir promedio
        int repetitions = 3;

        // Medir tiempos
        long timeGetByPrice = 0;
        long timeGetByPriceRange = 0;
        long timeGetByCategory = 0;

        for (int i = 0; i < repetitions; i++) {
            long start, end;

            start = System.currentTimeMillis();
            ds.getGamesByPrice(priceToSearch);
            end = System.currentTimeMillis();
            timeGetByPrice += (end - start);

            start = System.currentTimeMillis();
            ds.getGamesByPriceRange(lowerPrice, higherPrice);
            end = System.currentTimeMillis();
            timeGetByPriceRange += (end - start);

            start = System.currentTimeMillis();
            ds.getGamesByCategory(categoryToSearch);
            end = System.currentTimeMillis();
            timeGetByCategory += (end - start);
        }

        System.out.println("Resultados búsqueda lineal (promedio en ms, " + repetitions + " repeticiones):");
        System.out.printf("%-20s %-15s\n", "Método", "Tiempo promedio (ms)");
        System.out.printf("%-20s %-15d\n", "getGamesByPrice", timeGetByPrice / repetitions);
        System.out.printf("%-20s %-15d\n", "getGamesByPriceRange", timeGetByPriceRange / repetitions);
        System.out.printf("%-20s %-15d\n", "getGamesByCategory", timeGetByCategory / repetitions);
    }

    static ArrayList<Game> loadGamesFromFile(String filename) throws IOException {
        ArrayList<Game> list = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if(parts.length < 4) continue; // seguridad
            String name = parts[0];
            String category = parts[1];
            int price = Integer.parseInt(parts[2]);
            int quality = Integer.parseInt(parts[3]);
            list.add(new Game(name, category, price, quality));
        }
        br.close();
        return list;
    }
}