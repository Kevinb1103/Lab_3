import java.util.ArrayList;
import java.util.Random;

public class GenerateData {

    private static final String[] palabras = {"Dragon", "Empire", "Quest", "Galaxy", "Legends", "Warrior", "Shadow", "Mystic", "Chrono", "Blade"};
    private static final String[] categorias = {"Acción", "Aventura", "Estrategia", "RPG", "Deportes", "Simulación"};
    private static final Random rand = new Random();

    public static ArrayList<Game> generateGames(int n) {
        ArrayList<Game> games = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String name = palabras[rand.nextInt(palabras.length)] + palabras[rand.nextInt(palabras.length)];
            String category = categorias[rand.nextInt(categorias.length)];
            int price = rand.nextInt(70001); // 0 a 70000
            int quality = rand.nextInt(101); // 0 a 100

            games.add(new Game(name, category, price, quality));
        }

        return games;
    }

    // Método adicional para guardar en CSV (si no lo hiciste antes)
    public static void saveGamesToCSV(ArrayList<Game> games, String filename) {
        try (java.io.PrintWriter writer = new java.io.PrintWriter(filename)) {
            for (Game game : games) {
                writer.println(game.getName() + "," + game.getCategory() + "," + game.getPrice() + "," + game.getQuality());
            }
            System.out.println("Archivo guardado: " + filename);
        } catch (Exception e) {
            System.out.println("Error al guardar archivo: " + e.getMessage());
        }
    }
}