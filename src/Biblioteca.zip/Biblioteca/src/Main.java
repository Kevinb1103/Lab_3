import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Generar y guardar 3 archivos con tamaños diferentes
        ArrayList<Game> data100 = GenerateData.generateGames(100);
        GenerateData.saveGamesToCSV(data100, "games_100.csv");

        ArrayList<Game> data10000 = GenerateData.generateGames(10000);
        GenerateData.saveGamesToCSV(data10000, "games_10000.csv");

        ArrayList<Game> data1000000 = GenerateData.generateGames(1000000);
        GenerateData.saveGamesToCSV(data1000000, "games_1000000.csv");
    }
}