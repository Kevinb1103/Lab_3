import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class BinarySearchBenchmark {

    public static void main(String[] args) throws IOException {
        String filename = "games_1000000.csv";
        ArrayList<Game> games = loadGamesFromFile(filename);
        Dataset ds = new Dataset(games);

        // Valores seguros para buscar, extraídos del dataset:
        int testPrice = games.get(0).getPrice();
        int lowerPrice = testPrice - 100;  // rango aproximado
        int higherPrice = testPrice + 100;
        String testCategory = games.get(0).getCategory();

        System.out.printf("%-20s %-15s\n", "Método", "Tiempo promedio (ms)");

        // 1) getGamesByPrice
        ds.sortByAlgorithm("quickSort", "price");
        long totalTime = 0;
        int repetitions = 5;
        for (int i = 0; i < repetitions; i++) {
            long start = System.nanoTime();
            ds.getGamesByPrice(testPrice);
            long end = System.nanoTime();
            totalTime += (end - start);
        }
        System.out.printf("%-20s %-15.3f\n", "getGamesByPrice", totalTime / (repetitions * 1_000_000.0));

        // 2) getGamesByPriceRange
        ds.sortByAlgorithm("quickSort", "price");
        totalTime = 0;
        for (int i = 0; i < repetitions; i++) {
            long start = System.nanoTime();
            ds.getGamesByPriceRange(lowerPrice, higherPrice);
            long end = System.nanoTime();
            totalTime += (end - start);
        }
        System.out.printf("%-20s %-15.3f\n", "getGamesByPriceRange", totalTime / (repetitions * 1_000_000.0));

        // 3) getGamesByCategory
        ds.sortByAlgorithm("quickSort", "category");
        totalTime = 0;
        for (int i = 0; i < repetitions; i++) {
            long start = System.nanoTime();
            ds.getGamesByCategory(testCategory);
            long end = System.nanoTime();
            totalTime += (end - start);
        }
        System.out.printf("%-20s %-15.3f\n", "getGamesByCategory", totalTime / (repetitions * 1_000_000.0));
    }

    static ArrayList<Game> loadGamesFromFile(String filename) throws IOException {
        ArrayList<Game> list = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            String name = parts[0];
            String category = parts[1];
            int price = Integer.parseInt(parts[2]);
            int quality = Integer.parseInt(parts[3]);
            list.add(new Game(name, category, price, quality));
        }
        br.close();
        return list;
    }
}